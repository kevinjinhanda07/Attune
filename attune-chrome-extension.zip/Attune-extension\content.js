// Attune for Chrome: runs on every Google Doc. Adds the floating "Attune" button and the panel.
(() => {
  if (window.__attuneLoaded) return;
  window.__attuneLoaded = true;
  const m = location.pathname.match(/\/document\/d\/([^/]+)/);
  if (!m) return;
  const docId = m[1];
  const extOrigin = new URL(chrome.runtime.getURL('')).origin;
  const BAND = { fit: '#4F8B6B', drift: '#C29A3E', off: '#C3606F', none: '#9EA2A8' };

  const host = document.createElement('div');
  host.id = 'attune-root';
  const root = host.attachShadow({ mode: 'open' });
  root.innerHTML = `
  <style>
    :host{all:initial}
    .pill{position:fixed;right:22px;bottom:22px;z-index:2147483000;display:flex;align-items:center;gap:8px;
      height:40px;padding:0 14px 0 8px;border:0;border-radius:999px;background:#1D2024;color:#fff;cursor:pointer;
      font:500 13px/1 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;box-shadow:0 4px 18px rgba(0,0,0,.22);transition:transform .15s}
    .pill:hover{transform:translateY(-1px)}
    .pill img{width:24px;height:24px;border-radius:6px}
    .pill .score{min-width:26px;height:20px;padding:0 6px;border-radius:999px;background:var(--c,#9EA2A8);color:#fff;
      display:none;align-items:center;justify-content:center;font:600 11px/1 ui-monospace,Consolas,monospace}
    .pill .score.on{display:flex}
    .frame{position:fixed;top:104px;right:16px;bottom:16px;width:380px;max-width:calc(100vw - 32px);z-index:2147483001;
      border-radius:16px;overflow:hidden;background:#F8F8F6;box-shadow:0 10px 40px rgba(0,0,0,.18),0 1px 3px rgba(0,0,0,.08);
      border:1px solid #E6E6E2;transform-origin:bottom right;animation:in .22s cubic-bezier(.2,.8,.2,1)}
    @keyframes in{from{opacity:0;transform:translateY(8px) scale(.98)}to{opacity:1;transform:none}}
    .frame iframe{width:100%;height:100%;border:0;display:block}
    [hidden]{display:none!important}
    @media (prefers-reduced-motion:reduce){.frame{animation:none}.pill{transition:none}}
  </style>
  <button class="pill" id="pill" title="Open Attune"><img alt="" src="${chrome.runtime.getURL('icons/icon-48.png')}">Attune<span class="score" id="score"></span></button>
  <div class="frame" id="frame" hidden></div>`;
  document.documentElement.appendChild(host);

  const pill = root.getElementById('pill'), frame = root.getElementById('frame'), scoreEl = root.getElementById('score');
  let iframe = null;

  function open() {
    if (!iframe) {
      iframe = document.createElement('iframe');
      iframe.src = chrome.runtime.getURL('panel.html') + '#' + encodeURIComponent(docId);
      iframe.title = 'Attune';
      frame.appendChild(iframe);
    }
    frame.hidden = false; pill.hidden = true;
    chrome.storage.local.set({ 'attune.open': true });
  }
  function close() {
    frame.hidden = true; pill.hidden = false;
    chrome.storage.local.set({ 'attune.open': false });
  }
  pill.addEventListener('click', open);

  // Scroll the Google Docs page to roughly where a paragraph is (fraction 0..1 of the document).
  function scrollTo(fraction) {
    const ed = document.querySelector('.kix-appview-editor');
    if (!ed || typeof fraction !== 'number') return;
    const top = Math.max(0, fraction * ed.scrollHeight - ed.clientHeight * 0.3);
    ed.scrollTo({ top, behavior: 'smooth' });
  }

  window.addEventListener('message', (e) => {
    if (e.origin !== extOrigin || !e.data || typeof e.data !== 'object') return;
    const d = e.data;
    if (d.type === 'attune-close') close();
    if (d.type === 'attune-scroll') scrollTo(d.fraction);
    if (d.type === 'attune-score') {
      if (d.score == null) { scoreEl.classList.remove('on'); return; }
      scoreEl.textContent = d.score; scoreEl.style.setProperty('--c', BAND[d.band] || BAND.none); scoreEl.classList.add('on');
    }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'attune-toggle') (frame.hidden ? open : close)();
  });

  chrome.storage.local.get('attune.open').then((v) => { if (v['attune.open']) open(); }).catch(() => {});
})();
