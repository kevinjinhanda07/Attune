# Attune Chrome extension: setup guide

Install it once and Attune shows up on **every Google Doc** you open, like GPTZero. You don't need to paste a script into each document.

| Part | Setup needed |
|---|---|
| Scores, "Anyone / Your reader" labels, Needs work, Go to next, Deep review | **Step 1 only** (about 3 minutes) |
| Coloring paragraphs in the document, one-click word swaps | Step 1 **plus Step 2**, a one-time Google sign-in setup (about 10 minutes) |

---

## Step 1: Install the extension

1. **Unzip** the `attune-chrome-extension.zip` file. Put the folder somewhere permanent, for example `Documents\Attune-extension`. Chrome runs it from that folder, so don't delete or move it later.
2. In Chrome, go to **`chrome://extensions`** (type it in the address bar).
3. Turn on **Developer mode** (switch at the top right).
4. Click **Load unpacked** and select the folder. Pick the folder that contains `manifest.json`, not a folder above it.
5. Attune appears in the list. Click the **puzzle-piece icon** in Chrome's toolbar, then the **pin** next to Attune.
6. Open any Google Doc. A dark **Attune** button appears in the **bottom-right corner**. Click it to open the panel. You can also click Attune's icon in the toolbar.

The extension's ID shown on the `chrome://extensions` page should be **`ehkamnngdcegdbpmcbalbgdafcgnpekn`**. You'll need it in Step 2.

That's enough to use Attune. The panel reads your document automatically, the same way **File → Download** would.

---

## Step 2 (optional): Turn on colors and word swaps

To change your document, which means coloring paragraphs and applying word swaps, Attune needs permission through Google's official Docs API. You set up a free "Google Cloud project" once:

### 2a. Create the project
1. Go to **console.cloud.google.com** and sign in with the Google account you use for Docs.
2. At the top, click the project picker → **New project**. Name it `Attune` → **Create**. Make sure it's selected afterwards.

### 2b. Turn on the Google Docs API
1. Search the top bar for **Google Docs API** and open it.
2. Click **Enable**.

### 2c. Set up the sign-in screen
1. In the left menu, go to **APIs & Services → OAuth consent screen**. On newer screens this is called **Google Auth Platform**. Click **Get started**.
2. App name: `Attune`. Support email: your email. → **Next**.
3. Audience: **External** → **Next**.
4. Contact email: your email → **Next** → agree → **Create**.
5. Go to **Audience** (left menu) → **Test users** → **Add users**. Add your own Gmail address → **Save**.

### 2d. Create the extension's sign-in key
1. Go to **Clients** (or **Credentials → Create credentials → OAuth client ID**).
2. Application type: **Chrome Extension**.
3. Name: `Attune`. Item ID: **`ehkamnngdcegdbpmcbalbgdafcgnpekn`**.
4. Click **Create** and copy the **Client ID**. It ends in `.apps.googleusercontent.com`.

### 2e. Put the Client ID in the extension
1. In your extension folder, right-click **`manifest.json`** → **Open with → Notepad**.
2. Find `PASTE-YOUR-CLIENT-ID-HERE.apps.googleusercontent.com` and replace it with your Client ID. Keep the quotes.
3. Save and close.
4. Go to **`chrome://extensions`** and click the **↻ reload** arrow on Attune.

### 2f. Connect
1. Make sure **Chrome itself is signed in** with the same Google account (profile picture at the top right of Chrome). Chrome's sign-in is what Attune uses.
2. Open a Google Doc and open Attune. Near the score, click **Connect**.
3. Pick your account. You'll see "Google hasn't verified this app". That's normal for your own app: click **Continue** → **Continue**.
4. Your paragraphs turn green, yellow or pink in the document, and word swaps now work.

---

## Using it

It's the same Attune as the Apps Script version:

- **For:** describe your reader. This is saved per document, in your browser.
- **Needs work:** lists paragraphs in document order. **Go to next** scrolls you to each one.
- **Skipped:** titles, headings, tables and short labels.
- **Deep review:** click the **sliders icon** → paste your Anthropic API key → open a card → **Deep review with AI**.
- **Closing:** click **×** to close the panel. The **Attune** button in the corner reopens it.

**One difference:** in the Chrome version, **Go to** scrolls the page to the paragraph and flashes it, but it can't place your typing cursor there. Google only lets add-ons inside Docs do that.

---

## Updating Attune later

All versions share one panel:

1. Edit `google-docs/Sidebar.html`. For changes to Deep review, edit `google-docs/Code.gs`.
2. From the main project folder, run:
   ```
   node chrome-extension/build.js
   ```
3. Go to **`chrome://extensions`** → click **↻** on Attune → reload your Google Doc.

---

## If something goes wrong

| Problem | Fix |
|---|---|
| No Attune button on the Doc | Reload the Google Docs tab. Check that Attune is turned on in `chrome://extensions`. |
| "Attune could not read this document" | You need permission to download the doc (**File → Download** must be available). Reload the page. |
| **Connect** says sign-in was cancelled or isn't set up | Check Step 2e: the Client ID is pasted, you clicked ↻, and the ID on `chrome://extensions` matches the one in Step 2d. |
| "Access blocked: app has not completed verification" | Add your Gmail as a **Test user** (Step 2c, item 5). |
| Connect works but nothing gets colored | Make sure **Google Docs API** is enabled (Step 2b), and that **Color paragraphs** is on in Settings. |
| Error loading the extension | Select the folder that directly contains `manifest.json`. |

---

## Sharing it with others (later)

1. Pay the one-time $5 fee for a **Chrome Web Store developer account** (chrome.google.com/webstore/devconsole).
2. Zip the extension folder and upload it. Write a privacy policy: Attune reads people's documents, so this is required.
3. Before anyone outside your test users can click **Connect**, Google needs to verify the app. You request this in the Google Cloud console under **Verification Center**.
