// Clicking the Attune icon in Chrome's toolbar opens or closes the panel on a Google Doc.
// On any other page it opens Google Docs.
chrome.action.onClicked.addListener((tab) => {
  const isDoc = /^https:\/\/docs\.google\.com\/document\/d\//.test(tab.url || '');
  if (isDoc && tab.id) {
    chrome.tabs.sendMessage(tab.id, { type: 'attune-toggle' }).catch(() => chrome.tabs.reload(tab.id));
  } else {
    chrome.tabs.create({ url: 'https://docs.google.com/document/' });
  }
});
